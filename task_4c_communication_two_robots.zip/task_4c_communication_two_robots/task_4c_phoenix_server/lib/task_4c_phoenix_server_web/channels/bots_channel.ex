defmodule Task4CPhoenixServerWeb.BotsChannel do
  use Phoenix.Channel

  def join("bot:info", _params, socket) do
    {:ok, socket}
  end


  def handle_in("bot_A", message, socket) do

    mapp =  %{"a" => 1, "b" => 2, "c" => 3, "d" => 4, "e" => 5, "f" => 6}
    msg = %{"client" => "robot_A" or "robot_B", "left" => (message["x"]-1)*150, "bottom" => (mapp[message["y"]]-1)*150, "face" => message["face"]}
    :ok = Phoenix.PubSub.subscribe(Task4cPhoenixServer.PubSub, "robot:update")
    :ok = Phoenix.PubSub.broadcast(Task4cPhoenixServer.PubSub, "robot:update", msg)


    {:reply, {:ok}, socket}
  end
  
  def handle_in("bot_B", message, socket) do

    mapp =  %{"a" => 1, "b" => 2, "c" => 3, "d" => 4, "e" => 5, "f" => 6}
    msg = %{"client" => "robot_A" or "robot_B", "left" => (message["x"]-1)*150, "bottom" => (mapp[message["y"]]-1)*150, "face" => message["face"]}
    :ok = Phoenix.PubSub.subscribe(Task4cPhoenixServer.PubSub, "robot:update")
    :ok = Phoenix.PubSub.broadcast(Task4cPhoenixServer.PubSub, "robot:update", msg)


    {:reply, {:ok}, socket}
  end


end
