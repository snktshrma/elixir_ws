defmodule Task4CPhoenixServerWeb.AlgoBots do

  @vals_facing %{north: 1, east: 2, south: 3, west: 4}
  @vals_y %{a: 1, b: 2, c: 3, d: 4, e: 5}

  def main(robot, startB, goal_locs) do
  	goal_locs =  if length(goal_locs) > 6 do
                      for_a = begg(goal_locs,robot)
                      for_b = begg(goal_locs,startB)
                      uq = []
                      neww = alte(for_a,for_b,uq)
                      merge = Enum.uniq(neww)
                      merge = for a <- 0..5, do: Enum.at(merge,a)
                      cc = merge ++ goal_locs


                      nex = Enum.uniq(cc)
                      nex = nex -- cc -- nex

                      goals = arrange(robot,startB,merge)

                      startA = Enum.at((for x <- goals, Enum.at(x,-1) == "a", do: List.delete_at(x,-1)),-1)
                      startBB = Enum.at((for x <- goals, Enum.at(x,-1) == "b", do: List.delete_at(x,-1)),-1)
                      startA = List.insert_at(startA,-1,Enum.at(robot,-1))
                      startB = List.insert_at(startBB,-1,Enum.at(startB,-1))

                      goals_2 = if length(nex) > 6 do
                                  forr_a = begg(nex,startA)
                                  forr_b = begg(nex,startB)
                                  uqq = []
                                  newww = alte(forr_a,forr_b,uqq)
                                  merger = Enum.uniq(newww)
                                  merger = for a <- 0..5, do: Enum.at(merger,a)
                                  ccc = merger ++ nex


                                  nex = Enum.uniq(ccc)
                                  nex = nex -- ccc -- nex

                                  goal_s = arrange(startA,startB,merger)

                                  startAA = Enum.at((for x <- goal_s, Enum.at(x,-1) == "a", do: List.delete_at(x,-1)),-1)
                                  startBB = Enum.at((for x <- goal_s, Enum.at(x,-1) == "b", do: List.delete_at(x,-1)),-1)
                                  startA = List.insert_at(startAA,-1,Enum.at(startA,-1))
                                  startB = List.insert_at(startBB,-1,Enum.at(startB,-1))
                                  goal_s2 = arrange(startA,startB,nex)
                                  goals_2 = goal_s ++ goal_s2

                                else
                                  goals_2 = arrange(startA,startB,nex)

                                end

                      goal_locs = goals ++ goals_2
                  else

                    goal_locs = arrange(robot,startB,goal_locs)

      end
  end

  def begg(list,start) do
    li = []
    gg = for x <- list, do: subt(start,x)

    arri(list,gg,li)

  end

  def arri(list, gg, li) when length(list) == 1 do
    minn = Enum.min(gg)
    new = List.insert_at(li, -1, Enum.at(list,Enum.find_index(gg,fn x -> x == minn end)))
    new = for a <- 0..5, do: Enum.at(new,a)
  end

  def arri(list, gg, li) do

    minn = Enum.min(gg)
    new = List.insert_at(li, -1, Enum.at(list,Enum.find_index(gg,fn x -> x == minn end)))
    list = List.delete_at(list,Enum.find_index(gg,fn x -> x == minn end))
    gg = List.delete_at(gg,Enum.find_index(gg,fn x -> x == minn end))

    arri(list,gg,new)
  end

  def alte(l1,l2,lis,n) when n == length(l1)-1 do
    lis = List.insert_at(lis,-1,Enum.at(l1,n))
    lis = List.insert_at(lis,-1,Enum.at(l2,n))
  end

  def alte(l1,l2,lis, n \\ 0) do
    lis = List.insert_at(lis,-1,Enum.at(l1,n))
    lis = List.insert_at(lis,-1,Enum.at(l2,n))
    alte(l1,l2,lis,n+1)
  end

  def check(x,y) do
    x = if is_integer(x) do
          x
        else
          String.to_integer(x)
        end

    y = if is_atom(y) do
          y
        else
          String.to_atom(y)
        end

        [x,y]
  end



  def val_ext(list) do
    num = List.last(list)
    new = Enum.at(list,num)
    [a,b] = new
    x = if is_integer(a) do
          a
        else
          String.to_integer(a)
        end

    y = if is_atom(b) do
          b
        else
          String.to_atom(b)
        end
    [x,y]
  end



  def fort(list,n,start,bot,last,fin, ind) when ind == n-1 do
    x = Enum.at(list,ind)
    x = List.insert_at(x,0,[Enum.at(start,0),Enum.at(start,1)])
    nx = length(x)
    last = forx(x,nx,last,fin,Enum.at(start,2))
    list = for a <- list, do: for b <- a, do: List.insert_at(b,-1,bot)
    [Enum.min(last), Enum.at(list,Enum.find_index(last, fn x -> x == Enum.min(last) end))]
  end

  def fory(x,nx,inx,last,fin,face,ind) when ind == nx-1 do
    fin = List.insert_at(fin,-1,subt(Enum.at(x,inx),Enum.at(x,ind)))
    facing = face_error(Enum.at(Enum.at(x,inx),0), Enum.at(Enum.at(x,inx),1), Enum.at(Enum.at(x,ind),0), Enum.at(Enum.at(x,ind),1), face)
    sum = abs(Enum.at(facing,0)) + abs(Enum.at(facing,1))
    fin = List.insert_at(fin,-1,sum)

  end




  def fort(list,n,start,bot,last \\ [],fin \\ [],ind \\ 0) do
    x = Enum.at(list,ind)
    x = List.insert_at(x,0,[Enum.at(start,0),Enum.at(start,1)])
    nx = length(x)
    last = forx(x,nx,last,fin,Enum.at(start,2))

    fort(list,n,start,bot,last,fin,ind+1)
  end

  def forx(x,nx,last,fin,face,ind \\ 0) do


    fin = fory(x,nx,ind,last,fin,face)

    List.insert_at(last,-1,Enum.sum(fin))
  end

  def fory(x,nx,inx,last,fin,face,ind \\ 0) do

    fin = List.insert_at(fin,-1,subt(Enum.at(x,inx),Enum.at(x,ind)))
    facing = face_error(Enum.at(Enum.at(x,inx),0), Enum.at(Enum.at(x,inx),1), Enum.at(Enum.at(x,ind),0), Enum.at(Enum.at(x,ind),1), face)
    sum = abs(Enum.at(facing,0)) + abs(Enum.at(facing,1))
    fin = List.insert_at(fin,-1,sum)
    inx = ind

    sum2 = -Enum.at(facing,0) - Enum.at(facing,1)
    facen = @vals_facing[face] + sum2

    facen  = cond do

          facen > 4 -> facen - 4
          facen < 1 -> facen + 4
          true -> facen
         end

    face = cond do
          facen == 1 -> :north
          facen == 2 -> :east
          facen == 3 -> :south
          facen == 4 -> :west
         end
    fory(x,nx,inx,last,fin,face,ind+1)
  end

  def subt(a,b) do
    new = []
    x1 = Enum.at(a,0)
    x2 = Enum.at(b,0)
    y1 = Enum.at(a,1)
    y2 = Enum.at(b,1)
    [x1,y1] = check(x1,y1)
    [x2,y2] = check(x2,y2)
    y1 = @vals_y[y1]
    y2 = @vals_y[y2]
    x = abs(x1-x2)
    y = abs(y1-y2)
    new = List.insert_at(new,-1,x)
    new = List.insert_at(new,-1,y)
    Enum.sum(new)

  end



  def of([]) do
    [[]]
  end

  def of(list) do
    for h <- list, t <- of(list -- [h]), do: [h | t]
  end



  def arrange(startA,startB,goal_locs) do
    startA = startA
    startB = startB
    list = of(goal_locs)
    n = length(list)

    aa = Enum.at(fort(list,n,startA,"a"),1)

    bb = Enum.at(fort(list,n,startB,"b"),1)

    st = aa ++ bb
    impor(startA,startB,st,length(aa))
  end


  def without_repetitions([], _k), do: [[]]


  def without_repetitions(_list, 0), do: [[]]


  def without_repetitions(list, k) do
      for head <- list, tail <- without_repetitions(list -- [head], k - 1), do: [head | tail]
  end



  def impor(startA,startB,list,k,fii,mn,ind, rep) when ind == length(list) - 1 do

    x = Enum.at(list,ind)
    eA = for a <- x, Enum.at(a,2) == "a", do: List.delete_at(a,2)
    eB = for a <- x, Enum.at(a,2) == "b", do: List.delete_at(a,2)



    listA = of(eA)
    listB = of(eB)

    aa = fort(listA,length(listA),startA,"a")
    bb = fort(listB,length(listB),startB,"b")
    sumAB = Enum.at(aa,0) + Enum.at(bb,0)
    last = List.insert_at(mn,-1,sumAB)
    fii = List.insert_at(fii,-1,Enum.at(aa,1) ++ Enum.at(bb,1))
    Enum.at(fii,Enum.find_index(last, fn x -> x == Enum.min(last) end))

  end



  def impor(startA,startB,list,k,fii \\ [], mn \\ [],ind \\ 0, rep \\ 0) do
    if rep == 0 do
      lis = without_repetitions(list,k)
      new = for x <- (for a <- lis, do: Enum.uniq_by(a, fn [l,m,_] -> {l,m} end)), length(x) == k, do: x
      unique = for g <- new, do: Enum.sort(g)
      final = Enum.uniq(unique)
      impor(startA,startB,final,k,fii,mn,ind, rep+1)

    else
      x = Enum.at(list,ind)
      eA = for a <- x, Enum.at(a,2) == "a", do: List.delete_at(a,2)
      eB = for a <- x, Enum.at(a,2) == "b", do: List.delete_at(a,2)
      listA = of(eA)
      listB = of(eB)

      aa = fort(listA,length(listA),startA,"a")

      bb = fort(listB,length(listB),startB,"b")

      sumAB = Enum.at(aa,0) + Enum.at(bb,0)

      mn = List.insert_at(mn,-1,sumAB)
      fii = List.insert_at(fii,-1,Enum.at(aa,1) ++ Enum.at(bb,1))

      sumAB
      impor(startA,startB,list,k,fii,mn,ind+1,rep)

    end
  end


  def face_error(robot_x, robot_y, x, y, robot_facing) do

    goal_y = y
    goal_x = x

    [goal_x,goal_y] = check(goal_x,goal_y)
    [robot_x,robot_y] = check(robot_x,robot_y)

    error_x = goal_x - robot_x
    error_y = @vals_y[goal_y] - @vals_y[robot_y]


    ab = cond do
        error_y == 0 and error_x == 0 -> 0
        error_y != 0 ->
              cond do
                error_y > 0 and @vals_facing[robot_facing] == 4 -> -1

                error_y > 0 ->
                  err = @vals_facing[robot_facing] - 1

                  cond do
                    err == 2 and error_x != 0 or err == -2 and error_x != 0 ->
                      cond do
                        error_x < 0 and @vals_facing[robot_facing] == 1 -> 1

                        error_x > 0 ->
                          @vals_facing[robot_facing] - 2


                        error_x < 0 ->
                          @vals_facing[robot_facing] - 4
                      end
                    true -> err
                  end


                error_y < 0 ->
                  err = @vals_facing[robot_facing] - 3

                  cond do
                    err == 2 and error_x != 0 or err == -2 and error_x != 0 ->
                      cond do
                        error_x < 0 and @vals_facing[robot_facing] == 1 -> 1

                        error_x > 0 ->
                          @vals_facing[robot_facing] - 2

                        error_x < 0 ->
                          @vals_facing[robot_facing] - 4
                      end
                    true -> err
                  end
              end
          true -> 0
      end


    ba = cond do
        error_y == 0 and error_x == 0 -> 0
        error_x != 0 ->
              cond do
                error_x < 0 and @vals_facing[robot_facing] == 1 -> 1

                error_x > 0 ->
                  err = @vals_facing[robot_facing] - 2

                  cond do
                    err == 2 and error_y != 0 or err == -2 and error_y != 0 ->
                      cond do

                        error_y > 0 and @vals_facing[robot_facing] == 4 -> -1

                        error_y > 0 ->
                          @vals_facing[robot_facing] - 1

                        error_y < 0 ->
                          @vals_facing[robot_facing] - 3
                      end
                    true -> err
                  end


                error_x < 0 ->
                  err = @vals_facing[robot_facing] - 4

                  cond do
                    err == 2 and error_y != 0 or err == -2 and error_y != 0 ->
                      cond do
                        error_y > 0 and @vals_facing[robot_facing] == 4 -> -1

                        error_y > 0 ->
                          @vals_facing[robot_facing] - 1

                        error_y < 0 ->
                          @vals_facing[robot_facing] - 3

                      end
                    true -> err
                  end

              end
          true -> 0
      end

    [ab,ba]
  end




end
