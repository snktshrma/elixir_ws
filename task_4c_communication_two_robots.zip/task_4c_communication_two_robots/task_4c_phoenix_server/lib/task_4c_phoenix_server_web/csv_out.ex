defmodule Task4CPhoenixServerWeb.CsvOut do

  def csv_read(x, y, face) do
    Enum.to_list(CSV.decode!(File.stream!("Plant_Positions.csv")))
   
  end

end
