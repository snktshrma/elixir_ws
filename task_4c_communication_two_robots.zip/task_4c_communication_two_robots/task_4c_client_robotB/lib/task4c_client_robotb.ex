defmodule Task4CClientRobotB do
  # max x-coordinate of table top
  @table_top_x 6
  # max y-coordinate of table top
  @table_top_y :f
  # mapping of y-coordinates
  @robot_map_y_atom_to_num %{:a => 1, :b => 2, :c => 3, :d => 4, :e => 5, :f => 6}

  @doc """
  Places the robot to the default position of (1, A, North)

  Examples:

      iex> Task4CClientRobotB.place
      {:ok, %Task4CClientRobotB.Position{facing: :north, x: 1, y: :a}}
  """
  def place do
    {:ok, %Task4CClientRobotB.Position{}}
  end

  def place(x, y, _facing) when x < 1 or y < :a or x > @table_top_x or y > @table_top_y do
    {:failure, "Invalid position"}
  end

  def place(_x, _y, facing) when facing not in [:north, :east, :south, :west] do
    {:failure, "Invalid facing direction"}
  end

  @doc """
  Places the robot to the provided position of (x, y, facing),
  but prevents it to be placed outside of the table and facing invalid direction.

  Examples:

      iex> Task4CClientRobotB.place(1, :b, :south)
      {:ok, %Task4CClientRobotB.Position{facing: :south, x: 1, y: :b}}

      iex> Task4CClientRobotB.place(-1, :f, :north)
      {:failure, "Invalid position"}

      iex> Task4CClientRobotB.place(3, :c, :north_east)
      {:failure, "Invalid facing direction"}
  """
  def place(x, y, facing) do
    {:ok, %Task4CClientRobotB.Position{x: x, y: y, facing: facing}}
  end

  @doc """
  Provide START position to the robot as given location of (x, y, facing) and place it.
  """
  def start(x, y, facing) do
    place(x, y, facing)
  end

  @doc """
  Main function to initiate the sequence of tasks to achieve by the Client Robot B,
  such as connect to the Phoenix server, get the robot B's start and goal locations to be traversed.
  Call the respective functions from this module and others as needed.
  You may create extra helper functions as needed.
  """
  def main do

    ###########################
    ## complete this funcion ##
    ###########################

  end

  @doc """
  Provide GOAL positions to the robot as given location of [(x1, y1),(x2, y2),..] and plan the path from START to these locations.
  Make a call to ToyRobot.PhoenixSocketClient.send_robot_status/2 to get the indication of obstacle presence ahead of the robot.
  """

















  @vals_facing %{north: 1, east: 2, south: 3, west: 4}
  @vals_y %{a: 1, b: 2, c: 3, d: 4, e: 5}

  def retest(robot) do
    x = robot.x
    y = @vals_y[robot.y]
    f = @vals_facing[robot.facing]
    cond do
      y == 5 and x == 5 -> 0
      y == 1 and x == 1 -> 0
      y == 1 and x == 5 -> 0
      y == 5 and x == 1 -> 0



      y == 5 -> f - 3
      x == 1 -> f - 2
      y == 1 and f == 4 -> -1
      y == 1 and f == 2-> 1
      y == 1 and f == 1-> 0
      x == 5 and f == 1 -> 1
      x == 5 and f == 3 -> -1
      x == 5 and f == 4 -> 0
      true -> -1
    end
  end

  def parity(robot) do
    x = robot.x
    y = @vals_y[robot.y]
    f = @vals_facing[robot.facing]

    cond do
      y == 5 and x == 5 and f == 4 -> 1
      y == 5 and x == 5 and f == 3 -> -1
      y == 5 and x == 5 and f == 2 -> -1
      y == 5 and x == 5 and f == 1 -> 1

      y == 1 and x == 1 and f == 1 -> -1
      y == 1 and x == 1 and f == 2 -> 1
      y == 1 and x == 1 and f == 3 -> 1
      y == 1 and x == 1 and f == 4 -> -1

      y == 1 and x == 5 and f == 1 -> 1
      y == 1 and x == 5 and f == 4 -> -1
      y == 1 and x == 5 and f == 2 -> 1
      y == 1 and x == 5 and f == 3 -> -1

      y == 5 and x == 1 and f == 2 -> -1
      y == 5 and x == 1 and f == 3 -> 1
      y == 5 and x == 1 and f == 1 -> -1
      y == 5 and x == 1 and f == 4 -> 1
    end
  end


def for_check(n,robot,t,erro,er,goal_locs) when n == 1 do
    [goal_x,goal_y] = val_ext(goal_locs)
    if t == 'r' do
      recB(robot)
      robot = right(robot)
      ttr = mpid(robot)
      if ttr do
        avoid(robot,goal_locs,-1)
      else
        for_loop(erro, robot, er,goal_locs)
      end

    else
      recB(robot)
      robot = left(robot)
      ttr = mpid(robot)
      if ttr do
        avoid(robot,goal_locs,1)
      else
        for_loop(erro, robot, er,goal_locs)
      end
    end
  end



  def for_check(n,robot,t,erro, er,goal_locs) do
    [goal_x,goal_y] = val_ext(goal_locs)
    if t == 'r' do
      recB(robot)
      robot = right(robot)
      ttr = mpid(robot)
      if ttr do
        avoid(robot,goal_locs,-1)
      else
        for_check(n - 1, robot,t,erro,er,goal_locs)
      end
    else
      recB(robot)
      robot = left(robot)
      ttr = mpid(robot)
      if ttr do
        avoid(robot,goal_locs,1)
      else
        for_check(n - 1, robot,t,erro,er,goal_locs)
      end
    end
  end


  def con_check(n,robot,erro,er,goal_locs) do
    [goal_x,goal_y] = val_ext(goal_locs)
    cond do
      n >= 1 -> for_check(n,robot,'l',erro, er,goal_locs)
      n <= -1 -> for_check(n*(-1),robot,'r',erro, er,goal_locs)
      n==0 -> for_loop(erro, robot, er,goal_locs)
    end
  end


  def final_check(robot) do

    re = recB({:reached})
    re = Enum.at(Tuple.to_list(re),1)
    if re == {:reached} do
      {:ok, %CLI.Position{x: robot.x, y: robot.y, facing: robot.facing}}
    else
      final_check(robot)
    end
  end



  def for_loop(n,robot,er,goal_locs) when n == 1 and er == 0 do
    [goal_x,goal_y] = val_ext(goal_locs)
    recB(robot)
    robot = move(robot)
    len = length(goal_locs)
    num = List.last(goal_locs)
    if len-2 > num do
      new = List.delete(goal_locs,num)
      num = num + 1
      new = new ++ [num]
      stop(robot,new,:cli_robot_state)
    else
      ttr = mpid(robot)
      final_check(robot)

    end
  end


  def for_loop(n,robot,er,goal_locs) when n <= 1 do
    [goal_x,goal_y] = val_ext(goal_locs)
    robot = if n == 1 do
              recB(robot)
              robot = move(robot)
              robot
            else
              robot
            end


    stop(robot,goal_locs,:cli_robot_state)
  end



  def for_loop(n,robot,er,goal_locs) do
    [goal_x,goal_y] = val_ext(goal_locs)
    recB(robot)
    robot = move(robot)
    ttr = mpid(robot)
    if ttr do
      avoid(robot,goal_locs)
    else
      for_loop(n - 1, robot,er,goal_locs)
    end

  end


  def mpid(robot) do
    parent = self()
    pid = spawn_link(fn -> x = send_robot_status(robot, :cli_robot_state); send(parent, {:ok, x}) end)
    Process.register(pid, :client_toyrobotB)
    del(pid)
  end

  def del(pid) do
    parent = self()
    if Process.alive? pid do
      del(pid)
    else
      receive do
        {:ok,x} -> x
      end
    end
  end




  def avoid(robot,goal_locs,co \\ 0, test \\ 0,flag \\ -1, tf \\ 0) do
    [goal_x,goal_y] = val_ext(goal_locs)
    flg = 1
    {flag,tf}  = cond do
                  robot.x == 5 and @vals_y[robot.y] == 5 or robot.x == 1 and @vals_y[robot.y] == 1 or robot.x == 1 and @vals_y[robot.y] == 5 or robot.x == 5 and @vals_y[robot.y] == 1 -> {parity(robot),tf+1}
                  robot.x != 1 and robot.x != 5 and @vals_y[robot.y] != 1 and @vals_y[robot.y] != 5 -> {-co,tf}
                  true -> {flag,tf}
            end
    data = recB(robot)
    {robot, flag} = cond do
                      co != 0 ->
                          cond do
                            -co == 1 -> {left(robot), 1}

                            -co == -1 -> {right(robot), -1}
                          end

                      retest(robot) == 1 ->
                        {left(robot), 1}
                      retest(robot) == -1 ->
                        {right(robot), -1}
                      retest(robot) == 0 ->
                        {robot,flag} = if flag == -1 do
                                  {right(robot), -1}
                                else
                                  {left(robot), 1}
                                end
                    end
    ttr = mpid(robot)
    check_x = robot.x
    check_y = robot.y
    if ttr do
      avoid(robot,goal_locs,0,test+1,flag)
    else
      data = recB(robot)
      robot = move(robot)
      cond do
        test != 0 or tf != 0 ->
          flg = 1
          ttr = mpid(robot)
          data = recB(robot)
          robot = if flag == -1 do
                    left(robot)
                  else
                    right(robot)
                  end
          ttr = mpid(robot)
          if ttr do
            avoid(robot,goal_locs,0,test+1,flag)
          else
             data = recB(robot)
             robot = move(robot)

             stop(robot,goal_locs,:client_toyrobotB)
          end

        true -> stop(robot,goal_locs,:client_toyrobotB)
      end
    end
  end



  def check(x,y) do
    x = if is_integer(x) do
          x
        else
          String.to_integer(x)
        end

    y = if is_atom(y) do
          y
        else
          String.to_atom(y)
        end

        [x,y]
  end





  def val_ext(list) do
    num = List.last(list)
    new = Enum.at(list,num)
    [a,b] = new
    x = if is_integer(a) do
          a
        else
          String.to_integer(a)
        end

    y = if is_atom(b) do
          b
        else
          String.to_atom(b)
        end
    [x,y]
  end



  def rec(pid) do
    parent = self()
    if Process.alive? pid do
      rec(pid)
    else
      receive do
        {:ok,x} -> x
      end
    end
  end

  def recB(robot, n \\ 0) do
    x = cond do
      n == 0 ->
          parent = self()
          pidB = spawn_link(fn -> x = send_B(robot, :rec_A); send(parent, {:ok, x}) end)
          Process.register(pidB, :rec_B)
          rec(pidB)
      n == 1 ->
          parent = self()
          pidB = spawn_link(fn -> x = listen_from_A(); send(parent, {:ok, x}) end)
          Process.register(pidB, :rec_B)
          rec(pidB)
      n == 2 ->
          parent = self()
          a = [robot.x, robot.y, robot.facing]
          pidB = spawn_link(fn -> x = Process.send_after(:rec_A, {:ok, a},10) end)
        end
  end

  def send_B(robot, cli_robot_state) do
    Process.send_after(:rec_A, {:positionB,robot},10)
    # IO.puts("Sent by Toy Robot Client: #{x}, #{y}, #{facing}")
    listen_from_A()
  end

  def listen_from_A() do
    receive do
      {:positionA, robot} ->
        {:positionA, robot}

      {:ok,x} -> x
    end
  end




  def stop(robot, goal_locs) do
    goal_locs = if is_integer(List.last(goal_locs)) do
      goal_locs
    else
      recB(robot,2)
      goal_locs = recB(robot,1)
      goal_locs =  if length(goal_locs) != 0 and String.to_integer(Enum.at(Enum.at(goal_locs, 0),0)) == robot.x and String.to_atom(Enum.at(Enum.at(goal_locs, 0),1)) == robot.y do
                      goal_locs = List.delete_at(goal_locs,0)
                    else
                      goal_locs
                    end
      goal_locs = List.insert_at(goal_locs,-1,0)
    end


    if length(goal_locs) == 1 do
      ttr = mpid(robot)
      final_check(robot)
    else
      [x,y] = val_ext(goal_locs)

      goal_y = y
      goal_x = x

      error_x = goal_x - robot.x
      error_y = @vals_y[goal_y] - @vals_y[robot.y]
      ttr = mpid(robot)
      if ttr do
        avoid(robot,goal_locs)
      else
        if @vals_facing[robot.facing] == 1 and error_y != 0 or @vals_facing[robot.facing] == 3 and error_y != 0 or error_x == 0 do
          cond do
            error_y == 0 and error_x == 0 -> {:ok,robot}
            error_y > 0 and @vals_facing[robot.facing] == 4 ->
              err = -1
              con_check(err,robot,error_y,error_x,goal_locs)
            error_y > 0 ->
              err = @vals_facing[robot.facing] - 1

              cond do
                err == 2 and error_x != 0 or err == -2 and error_x != 0 ->
                  cond do
                    error_x < 0 and @vals_facing[robot.facing] == 1 ->
                      err = 1
                      con_check(err,robot,error_x*(-1),error_y,goal_locs)
                    error_x > 0 ->
                      err = @vals_facing[robot.facing] - 2
                      con_check(err,robot,error_x, error_y,goal_locs)
                    error_x < 0 ->
                      err = @vals_facing[robot.facing] - 4
                      con_check(err,robot,error_x*(-1),error_y,goal_locs)
                  end
                true -> con_check(err,robot,error_y,error_x,goal_locs)
              end


            error_y < 0 ->
              err = @vals_facing[robot.facing] - 3

              cond do
                err == 2 and error_x != 0 or err == -2 and error_x != 0 ->
                  cond do
                    error_x < 0 and @vals_facing[robot.facing] == 1 ->
                      err = 1
                      con_check(err,robot,error_x*(-1),error_y,goal_locs)
                    error_x > 0 ->
                      err = @vals_facing[robot.facing] - 2
                      con_check(err,robot,error_x, error_y,goal_locs)
                    error_x < 0 ->
                      err = @vals_facing[robot.facing] - 4
                      con_check(err,robot,error_x*(-1),error_y,goal_locs)
                  end
                true -> con_check(err,robot,error_y*(-1),error_x,goal_locs)
              end

            error_y == 0 -> for_loop(error_y, robot, error_x,goal_locs)
          end
        else
          cond do
            error_x < 0 and @vals_facing[robot.facing] == 1 ->
              err = 1
              con_check(err,robot,error_x*(-1),error_y,goal_locs)
            error_x > 0 ->
              err = @vals_facing[robot.facing] - 2


              cond do
                err == 2 and error_y != 0 or err == -2 and error_y != 0 ->
                  cond do
                    error_y > 0 and @vals_facing[robot.facing] == 4 ->
                      err = -1
                      con_check(err,robot,error_y,error_x,goal_locs)
                    error_y > 0 ->
                      err = @vals_facing[robot.facing] - 1
                      con_check(err,robot,error_y,error_x,goal_locs)
                    error_y < 0 ->
                      err = @vals_facing[robot.facing] - 3
                      con_check(err,robot,error_y*(-1),error_x,goal_locs)
                  end
                true -> con_check(err,robot,error_x, error_y,goal_locs)
              end


            error_x < 0 ->
              err = @vals_facing[robot.facing] - 4

              cond do
                err == 2 and error_y != 0 or err == -2 and error_y != 0 ->
                  cond do
                    error_y > 0 and @vals_facing[robot.facing] == 4 ->
                      err = -1
                      con_check(err,robot,error_y,error_x,goal_locs)
                    error_y > 0 ->
                      err = @vals_facing[robot.facing] - 1
                      con_check(err,robot,error_y,error_x,goal_locs)
                    error_y < 0 ->
                      err = @vals_facing[robot.facing] - 3
                      con_check(err,robot,error_y*(-1),error_x,goal_locs)
                  end
                true -> con_check(err,robot,error_x*(-1),error_y,goal_locs)
              end

            error_x == 0 -> for_loop(error_x, robot, error_y,goal_locs)
          end
        end
      end
    end
  end









  @doc """
  Provides the report of the robot's current position

  Examples:

      iex> {:ok, robot} = Task4CClientRobotB.place(2, :b, :west)
      iex> Task4CClientRobotB.report(robot)
      {2, :b, :west}
  """
  def report(%Task4CClientRobotB.Position{x: x, y: y, facing: facing} = _robot) do
    {x, y, facing}
  end

  @directions_to_the_right %{north: :east, east: :south, south: :west, west: :north}
  @doc """
  Rotates the robot to the right
  """
  def right(%Task4CClientRobotB.Position{facing: facing} = robot) do
    %Task4CClientRobotB.Position{robot | facing: @directions_to_the_right[facing]}
  end

  @directions_to_the_left Enum.map(@directions_to_the_right, fn {from, to} -> {to, from} end)
  @doc """
  Rotates the robot to the left
  """
  def left(%Task4CClientRobotB.Position{facing: facing} = robot) do
    %Task4CClientRobotB.Position{robot | facing: @directions_to_the_left[facing]}
  end

  @doc """
  Moves the robot to the north, but prevents it to fall
  """
  def move(%Task4CClientRobotB.Position{x: _, y: y, facing: :north} = robot) when y < @table_top_y do
    %Task4CClientRobotB.Position{ robot | y: Enum.find(@robot_map_y_atom_to_num, fn {_, val} -> val == Map.get(@robot_map_y_atom_to_num, y) + 1 end) |> elem(0)
    }
  end

  @doc """
  Moves the robot to the east, but prevents it to fall
  """
  def move(%Task4CClientRobotB.Position{x: x, y: _, facing: :east} = robot) when x < @table_top_x do
    %Task4CClientRobotB.Position{robot | x: x + 1}
  end

  @doc """
  Moves the robot to the south, but prevents it to fall
  """
  def move(%Task4CClientRobotB.Position{x: _, y: y, facing: :south} = robot) when y > :a do
    %Task4CClientRobotB.Position{ robot | y: Enum.find(@robot_map_y_atom_to_num, fn {_, val} -> val == Map.get(@robot_map_y_atom_to_num, y) - 1 end) |> elem(0)}
  end

  @doc """
  Moves the robot to the west, but prevents it to fall
  """
  def move(%Task4CClientRobotB.Position{x: x, y: _, facing: :west} = robot) when x > 1 do
    %Task4CClientRobotB.Position{robot | x: x - 1}
  end

  @doc """
  Does not change the position of the robot.
  This function used as fallback if the robot cannot move outside the table
  """
  def move(robot), do: robot

  def failure do
    raise "Connection has been lost"
  end
end
